import pandas as pd
import numpy as np
from sklearn.preprocessing import LabelEncoder, StandardScaler
from sklearn.cluster import KMeans
from sklearn.neighbors import KNeighborsClassifier
from sklearn.model_selection import train_test_split
from sklearn.decomposition import PCA
from sklearn.metrics import classification_report
import matplotlib.pyplot as plt
import seaborn as sns

# تولید داده‌های ساختگی
np.random.seed(0)
نام‌ها = ["امیر", "زهرا", "محمد", "سارا", "رضا", "فاطمه", "مهدی", "نگار", "آرمین", "رعنا"]
جنسیت = ["مرد", "زن"]
رشته‌ها = ["مهندسی", "پزشکی", "هنر", "علوم انسانی"]
شهرها = ["تهران", "شیراز", "اصفهان", "تبریز", "مشهد"]
بیماری‌ها = ["ندارد", "دیابت", "فشار خون", "آسم"]
پدیده = ["A", "B", "C"]

داده‌ها = []
for i in range(100):
    ردیف = {
        "شناسه": i + 1,
        "نام": np.random.choice(نام‌ها),
        "جنسیت": np.random.choice(جنسیت),
        "رشته": np.random.choice(رشته‌ها),
        "شهر": np.random.choice(شهرها),
        "بیماری خاص": np.random.choice(بیماری‌ها),
        "سن": np.random.randint(18, 60),
        "قد": np.random.randint(150, 200),
        "وزن": np.random.randint(50, 100),
        "ساعات خواب": np.random.randint(4, 10),
        "ساعات مطالعه": np.random.randint(0, 6),
        "ساعات ورزش": np.random.randint(0, 5),
        "سیگار": np.random.choice([0, 1]),
        "رژیم غذایی": np.random.choice([0, 1]),
        "سطح استرس": np.random.randint(1, 10),
        "ساعات استفاده از موبایل": np.random.randint(1, 10),
        "برچسب پدیده": np.random.choice(پدیده)
    }
    داده‌ها.append(ردیف)

df = pd.DataFrame(داده‌ها)

# ذخیره فایل‌ها
df.to_csv("phenomenon_dataset.csv", index=False, encoding='utf-8-sig')
df.to_excel("phenomenon_dataset.xlsx", index=False)

# پردازش داده‌ها
df_processed = df.copy()
ستون_های_متنی = ["نام", "جنسیت", "رشته", "شهر", "بیماری خاص", "برچسب پدیده"]
رمزگذارها = {}

for ستون in ستون_های_متنی:
    encoder = LabelEncoder()
    df_processed[ستون] = encoder.fit_transform(df_processed[ستون])
    رمزگذارها[ستون] = encoder

ویژگی‌ها = df_processed.drop(columns=["شناسه", "برچسب پدیده"])
برچسب‌ها = df_processed["برچسب پدیده"]

# نرمال‌سازی
scaler = StandardScaler()
ویژگی‌های_نرمال = scaler.fit_transform(ویژگی‌ها)

# خوشه‌بندی با KMeans
kmeans = KMeans(n_clusters=3, random_state=0)
برچسب‌های_kmeans = kmeans.fit_predict(ویژگی‌های_نرمال)

# طبقه‌بندی با KNN
X_train, X_test, y_train, y_test = train_test_split(ویژگی‌های_نرمال, برچسب‌ها, test_size=0.2, random_state=42)
knn = KNeighborsClassifier(n_neighbors=5)
knn.fit(X_train, y_train)
پیش‌بینی = knn.predict(X_test)

# گزارش عملکرد KNN
گزارش = classification_report(y_test, پیش‌بینی, target_names=رمزگذارها["برچسب پدیده"].classes_)
with open("knn_classification_report.txt", "w", encoding="utf-8") as f:
    f.write("گزارش طبقه‌بندی KNN\n")
    f.write(گزارش)

# کاهش ابعاد با PCA و ترسیم نمودار خوشه‌بندی
pca = PCA(n_components=2)
ویژگی‌های_pca = pca.fit_transform(ویژگی‌های_نرمال)

plt.figure(figsize=(8, 6))
sns.scatterplot(x=ویژگی‌های_pca[:, 0], y=ویژگی‌های_pca[:, 1], hue=برچسب‌های_kmeans, palette='Set2', s=60)
plt.title("خوشه‌بندی KMeans با استفاده از PCA")
plt.xlabel("مولفه اصلی ۱")
plt.ylabel("مولفه اصلی ۲")
plt.legend(title="خوشه")
plt.tight_layout()
plt.savefig("kmeans_clustering_plot.png")
plt.close()
